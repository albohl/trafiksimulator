package trafiksimulator;

public class Light {
    private int period;
    private int time;  // Intern klocka: 0, 1, ... period-1, 0, 1 ...
    private int green; // Signalen gr�n n�r time<green 

    public Light(int period, int green) {
    	this.period = period;
    	this.green = green;
    }

    public void    step() { 
       // Stegar fram klocka ett steg
    }

    public boolean isGreen()   {
	// Returnerar true om time<green, annars false
    	return false;
    }

    public String  toString()  {
    	return "Light(period = " + this.period + ", time = " + this.time + ", green = "  + this.green + ")";
    }
	
}